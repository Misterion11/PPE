<form class="changement" action="Reserver.php" method="post">
  <legend class="modif">Veuillez entrer le numéro de l'activité pour vous inscrire : </legend>
  <table>
    <tr class="modif">
      <td>Numéro de l'Activité : <br> <input type="text" name="NumInscr" value="" maxlength="5" ></td>
    </tr>
  </table>
  <div class="center"><input class="bouton" type="submit" name="Inscrip" value="S'inscrire"></div>
</form>
