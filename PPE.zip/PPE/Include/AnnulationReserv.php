<form class="changement" action="Reserver.php" method="post">
  <legend class="modif">Veuillez entrer le numéro d'inscription pour vous désinscrire : </legend>
  <table>
    <tr class="modif">
      <td>Numéro de l'Activité : <br> <input type="text" name="NumInscri" value="" maxlength="5" ></td>
    </tr>
  </table>
  <div class="center"><input class="bouton" type="submit" name="désinscrire" value="Se désinscrire"></div>
</form>
