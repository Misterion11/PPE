<form class="changement" action="Reserver.php" method="post">
  <legend class="modif">Voici les activités auquels vous êtes incrits : </legend>
  <table class='presta'><tr><th class='presta'> Numéro d'Inscription </th><th class='presta'> Numéro de l'activité </th><th class='presta'> Date de l'inscription </th></tr>
